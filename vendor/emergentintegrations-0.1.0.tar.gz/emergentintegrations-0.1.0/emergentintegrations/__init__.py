"""
Entegrations is a Python library for various integrations including payment processors and LLM services.
"""

__version__ = "0.1.0"